#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <strings.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

/* external variables */
extern char **environ;

#define MAXLINE 8192 /* Max text line length */
#define MAXBUF 8192

void unix_error( char *msg );

void app_error( char *msg );

char *Fgets( char *, int, FILE * );

pid_t Fork( void );

void Kill( pid_t pid, int signum );

void Pause(void);

typedef void handler_t(int);
handler_t *Signal( int signum, handler_t *handler );

/*********************************
 * Wrappers for Unix I/O functions
 * *******************************/

int Open( char *filename, int flag, mode_t mode );
ssize_t Read( int fd, void *buf, size_t n );
ssize_t Write( int fd, const void *buf, size_t n );
void Close( int fd );

/***********************************
 * 不带缓冲的RIO版本
 * ********************************/
ssize_t rio_readn( int fd, void *buf, size_t n );
ssize_t rio_writen( int fd, void *buf, size_t n );

/***********************************
 * 带I/O缓冲的RIO版本
 *********************************/
#define RIO_BUFSIZE 8192
typedef struct {
	int rio_fd;		//Descritor for this internal buf
	int rio_cnt;	//Unread bytes in internal buf
	char *rio_bufptr;//Next unread byte in internal buf
	char rio_buf[RIO_BUFSIZE];//Internal buf
} rio_t;

void rio_readInitb( rio_t *rp, int fd );
static ssize_t rio_read( rio_t *rp, char *usrbuf, size_t n );
ssize_t rio_readlineb( rio_t *rp, void *usrbuf, size_t maxlen );
ssize_t rio_readnb( rio_t *rp, void *usrbuf, size_t n );

/*************************
 * 网络套接字编程
 * **********************/
typedef struct sockaddr SA;
#define LISTENQ 1024
int open_clientfd( char *hostname, int port );
int open_listenfd( int port );
